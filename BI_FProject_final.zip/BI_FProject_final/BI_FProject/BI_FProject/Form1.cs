﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace BI_FProject
{
    public partial class Form1 : Form
    {
        private DataTable dataTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
            InitializeData();
            PopulateComboBox();
        }

        private void InitializeData()
        {
            LoadData();
        }

        private void LoadData()
        {
            string filePath = "best-selling-books.csv";

            dataTable = new DataTable();
            dataTable.Columns.Add("Book");
            dataTable.Columns.Add("Author(s)");
            dataTable.Columns.Add("Original language");
            dataTable.Columns.Add("First published", typeof(int));
            dataTable.Columns.Add("Approximate sales in millions", typeof(double));
            dataTable.Columns.Add("Genre");

            try
            {
                var lines = File.ReadAllLines(filePath);

                for (int i = 1; i < lines.Length; i++)
                {
                    var values = lines[i].Split(',');

                    string book = values[0];
                    string author = values[1];
                    string language = values[2];

                    if (!int.TryParse(values[3], out int firstPublished))
                    {
                        continue;
                    }

                    if (!double.TryParse(values[4], System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double sales))
                    {
                        continue;
                    }

                    string genre = values[5];
                    dataTable.Rows.Add(book, author, language, firstPublished, sales, genre);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la citirea fișierului CSV: {ex.Message}");
            }
        }

        private void comboBoxTop_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Actualizez statistica atunci când schimb top 5 top 10
            ButtonTask1_Click(sender, e);
        }

        private void ButtonTask1_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            panelTask1.Visible = true;

            // Setează titlul task-ului
            Label titleLabel = new Label
            {
                Text = "Cele mai bine vândute cărți",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // Adaugă descrierea pentru DataGridView și Chart
            Label dataLabel = new Label
            {
                Text = "Tabelul de mai jos arată top 5/10 cele mai bine vândute cărți, iar graficul oferă distribuția procentuală a vânzărilor.",
                Font = new Font("Arial", 10),
                Location = new Point(20, 40),
                AutoSize = true
            };

            // Configurează comboBox-ul pentru selecția topului
            comboBoxTop.Location = new Point(20, 70);
            comboBoxTop.Visible = true;
            comboBoxTop.BringToFront();
            comboBoxTop.SelectedIndex = 0;

            UpdateTopBooks();  // Actualizează tabelul și graficul

            // Setează locația și dimensiunea DataGridView
            dataGridView1.Size = new Size(400, 300);
            dataGridView1.Location = new Point(20, 110);

            // Setează locația și dimensiunea graficului
            chart1.Size = new Size(400, 300);
            chart1.Location = new Point(450, 110);

            // Adaugă toate elementele în panel
            panelTask1.Controls.Clear();
            panelTask1.Controls.Add(titleLabel);
            panelTask1.Controls.Add(dataLabel);
            panelTask1.Controls.Add(comboBoxTop);
            panelTask1.Controls.Add(dataGridView1);
            panelTask1.Controls.Add(chart1);
        }
        private void ComboBoxTop_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTopBooks();
        }
        private void UpdateTopBooks()
        {
            if (dataTable != null)
            {
                // Determină dacă se va afișa top 5 sau top 10
                var topCount = comboBoxTop.SelectedItem?.ToString() == "Top 10" ? 10 : 5;

                var topBooks = dataTable.AsEnumerable()
                    .OrderByDescending(row => row.Field<double>("Approximate sales in millions"))
                    .Take(topCount)
                    .CopyToDataTable();

                dataGridView1.DataSource = topBooks;
                chart1.Series.Clear();
                chart1.ChartAreas.Clear();
                chart1.ChartAreas.Add(new ChartArea("MainArea"));

                Series series = new Series
                {
                    Name = "Vânzări",
                    ChartType = SeriesChartType.Pie,
                    IsValueShownAsLabel = true,
                    LabelForeColor = Color.White
                };

                double totalSales = topBooks.AsEnumerable().Sum(row => row.Field<double>("Approximate sales in millions"));
                foreach (var book in topBooks.AsEnumerable())
                {
                    string bookTitle = book.Field<string>("Book");
                    double sales = book.Field<double>("Approximate sales in millions");
                    double percentage = (sales / totalSales) * 100;
                    series.Points.AddXY(bookTitle, percentage);
                    series.Points.Last().Label = $"{percentage:F2}%";
                }

                chart1.Series.Add(series);
                chart1.Legends.Clear();
                chart1.Legends.Add(new Legend("Legend")
                {
                    Docking = Docking.Right,
                    Alignment = StringAlignment.Center
                });

                panelTask1.Controls.Clear();
                panelTask1.Controls.Add(comboBoxTop);
                panelTask1.Controls.Add(dataGridView1);
                panelTask1.Controls.Add(chart1);
            }
        }
        private void ButtonTask2_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            panelTask2.Visible = true;

            // ComboBox pentru selectarea genului de carte
            ComboBox comboBoxGenre = new ComboBox
            {
                Location = new Point(20, 20),
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Adăugăm genurile distincte din baza de date în ComboBox
            var genres = dataTable.AsEnumerable()
                .Select(row => row.Field<string>("Genre"))
                .Distinct()
                .OrderBy(genre => genre)
                .ToList();
            comboBoxGenre.Items.AddRange(genres.Cast<object>().ToArray());

            // Buton pentru confirmarea selecției genului
            Button confirmButton = new Button
            {
                Text = "Afișează Evoluția Vânzărilor",
                Location = new Point(240, 20),
                Width = 160,
            };

            confirmButton.Click += (s, args) =>
            {
                // Verificăm dacă un gen este selectat
                if (comboBoxGenre.SelectedItem == null)
                {
                    MessageBox.Show("Selectați un gen.");
                    return;
                }

                string selectedGenre = comboBoxGenre.SelectedItem.ToString();

                // Filtrăm datele pentru genul selectat și grupăm după an
                var filteredData = dataTable.AsEnumerable()
                    .Where(row => row.Field<string>("Genre") == selectedGenre)
                    .GroupBy(row => row.Field<int>("First Published"))
                    .Select(group => new
                    {
                        Year = group.Key,
                        TotalSales = group.Sum(row => row.Field<double>("Approximate sales in millions"))
                    })
                    .OrderBy(x => x.Year)
                    .ToList();

                // Configurăm DataGridView pentru a afișa datele
                dataGridView1.DataSource = filteredData;
                dataGridView1.Size = new Size(700, 300); // Extindem dimensiunea DataGridView
                dataGridView1.Location = new Point(20, 60);
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.Columns[0].HeaderText = "Anul";
                dataGridView1.Columns[1].HeaderText = "Vânzări Totale (mil. exemplare)";

                // Creăm și configurăm graficul pentru a ilustra vânzările pe ani
                Chart salesChart = new Chart
                {
                    Size = new Size(800, 400), // Ajustăm dimensiunea graficului
                    Location = new Point(20, 380)
                };
                salesChart.ChartAreas.Add(new ChartArea("MainArea"));

                Series series = new Series
                {
                    Name = "Evoluția Vânzărilor",
                    ChartType = SeriesChartType.Line,
                    BorderWidth = 2,
                    Color = Color.Green
                };

                foreach (var dataPoint in filteredData)
                {
                    series.Points.AddXY(dataPoint.Year, dataPoint.TotalSales);
                }

                salesChart.Series.Add(series);

                // Configurăm axele pentru o lizibilitate mai bună
                salesChart.ChartAreas[0].AxisX.Title = "Anul";
                salesChart.ChartAreas[0].AxisY.Title = "Vânzări (mil. exemplare)";
                salesChart.ChartAreas[0].AxisX.Interval = 1; // Afișăm fiecare an pe axa X
                salesChart.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;
                salesChart.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;

                // Extindem panoul pentru a se potrivi cu graficul și DataGridView
                panelTask2.Size = new Size(900, 800);

                // Curățăm și adăugăm controalele în panou
                panelTask2.Controls.Clear();
                panelTask2.Controls.Add(comboBoxGenre);
                panelTask2.Controls.Add(confirmButton);
                panelTask2.Controls.Add(dataGridView1);
                panelTask2.Controls.Add(salesChart);
            };

            // Adăugăm ComboBox-ul și butonul în panou
            panelTask2.Controls.Clear();
            panelTask2.Controls.Add(comboBoxGenre);
            panelTask2.Controls.Add(confirmButton);
        }





        private void ButtonTask3_Click(object sender, EventArgs e)
        {
            // Ascunde celelalte panouri și afișează panoul curent
            HideAllPanels();
            panelTask3.Visible = true;

            // Adăugăm titlul și descrierea pentru grafic
            Label titleLabel = new Label
            {
                Text = "Vânzări de cărți pe intervalul de timp selectat",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 10),
                AutoSize = true
            };

            // ComboBox pentru selectarea anului de început
            ComboBox comboBoxStartYear = new ComboBox
            {
                Location = new Point(20, 50),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // ComboBox pentru selectarea anului de final
            ComboBox comboBoxEndYear = new ComboBox
            {
                Location = new Point(140, 50),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Populăm ComboBox-urile cu anii disponibili în baza de date
            var years = dataTable.AsEnumerable()
                .Select(row => row.Field<int>("First Published"))
                .Distinct()
                .OrderBy(year => year)
                .ToList();

            comboBoxStartYear.Items.AddRange(years.Cast<object>().ToArray());
            comboBoxEndYear.Items.AddRange(years.Cast<object>().ToArray());

            // Buton pentru confirmarea selecției intervalului de ani
            Button confirmButton = new Button
            {
                Text = "Generează",
                Location = new Point(260, 50),
                Width = 120,
            };
            confirmButton.Click += (s, args) =>
            {
                // Validare: Verificăm dacă anii sunt selectați și validi
                if (comboBoxStartYear.SelectedItem == null || comboBoxEndYear.SelectedItem == null)
                {
                    MessageBox.Show("Selectați atât anul de început, cât și anul de final.");
                    return;
                }

                int startYear = (int)comboBoxStartYear.SelectedItem;
                int endYear = (int)comboBoxEndYear.SelectedItem;

                if (startYear > endYear)
                {
                    MessageBox.Show("Anul de început trebuie să fie mai mic sau egal cu anul de final.");
                    return;
                }

                // Filtrăm datele în funcție de intervalul selectat
                var filteredData = dataTable.AsEnumerable()
                    .Where(row => row.Field<int>("First Published") >= startYear &&
                                  row.Field<int>("First Published") <= endYear)
                    .GroupBy(row => row.Field<int>("First Published"))
                    .Select(group => new
                    {
                        Year = group.Key,
                        TotalSales = group.Sum(row => row.Field<double>("Approximate sales in millions")) 
                    })
                    .OrderBy(x => x.Year)
                    .ToList();

                // Creăm graficul pentru a ilustra vânzările
                Chart salesChart = new Chart
                {
                    Size = new Size(1200, 500), // Ajustăm înălțimea graficului la 600 pentru mai mult spațiu
                    Location = new Point(20, 100)
                };
                salesChart.ChartAreas.Add(new ChartArea("MainArea"));

                // Ajustăm dimensiunile panoului pentru a se potrivi graficului extins
                panelTask3.Size = new Size(900, 700); // Mărim înălțimea panoului pentru a avea loc întreg graficul

                Series series = new Series
                {
                    Name = "Vânzări pe An",
                    ChartType = SeriesChartType.Line,
                    BorderWidth = 2,
                    Color = Color.Blue
                };

                foreach (var dataPoint in filteredData)
                {
                    series.Points.AddXY(dataPoint.Year, dataPoint.TotalSales);
                }

                salesChart.Series.Add(series);

                // Configurăm axele graficului
                salesChart.ChartAreas[0].AxisX.Title = "Anul";
                salesChart.ChartAreas[0].AxisY.Title = "Vânzări";

                // Ajustează dimensiunile panoului pentru a se potrivi graficului
                panelTask3.Size = new Size(1200, 600);

                // Curățăm și adăugăm elementele pe panou
                panelTask3.Controls.Clear();
                panelTask3.Controls.Add(titleLabel);
                panelTask3.Controls.Add(comboBoxStartYear);
                panelTask3.Controls.Add(comboBoxEndYear);
                panelTask3.Controls.Add(confirmButton);
                panelTask3.Controls.Add(salesChart);
            };

            // Adăugăm controalele pe panou
            panelTask3.Controls.Clear();
            panelTask3.Controls.Add(titleLabel);
            panelTask3.Controls.Add(comboBoxStartYear);
            panelTask3.Controls.Add(comboBoxEndYear);
            panelTask3.Controls.Add(confirmButton);
        }



        private void ButtonTask4_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            panelTask4.Visible = true;

            // Configurăm opțiunile ComboBox-ului
            comboBoxTop.Items.Clear();
            comboBoxTop.Items.Add("Top 5");
            comboBoxTop.Items.Add("Top 10");
            comboBoxTop.Items.Add("Top 15");
            comboBoxTop.SelectedIndex = 0; // Selectăm implicit Top 5
            comboBoxTop.Visible = true;
            comboBoxTop.Location = new Point(20, 20); // Mutăm ComboBox-ul mai sus pentru a evita suprapunerea

            // Eveniment pentru schimbarea selecției în ComboBox
            comboBoxTop.SelectedIndexChanged += (s, ev) => UpdateAuthorProductivity();

            UpdateAuthorProductivity(); // Apelează funcția pentru a încărca datele inițiale
        }

        private void UpdateAuthorProductivity()
        {
            if (dataTable != null)
            {
                // Determinăm numărul de autori de afișat în funcție de selecția din ComboBox
                int topCount = 5;
                if (comboBoxTop.SelectedItem?.ToString() == "Top 10") topCount = 10;
                else if (comboBoxTop.SelectedItem?.ToString() == "Top 15") topCount = 15;

                // Grupați după autori și calculați vânzările totale pentru fiecare
                var authorProductivity = dataTable.AsEnumerable()
                    .GroupBy(row => row.Field<string>("Author(s)"))
                    .Select(group => new
                    {
                        Author = group.Key,
                        TotalSales = group.Sum(row => row.Field<double>("Approximate sales in millions"))
                    })
                    .OrderByDescending(x => x.TotalSales)
                    .Take(topCount) // Ia doar numărul specificat de autori
                    .ToList();

                // Configurăm DataGridView pentru afișare
                dataGridView1.DataSource = authorProductivity;
                dataGridView1.Size = new Size(700, 600); // Extindem și mai mult dimensiunea verticală
                dataGridView1.Location = new Point(20, 60); // Mutăm DataGridView-ul mai jos pentru a nu se suprapune cu ComboBox-ul
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Ajustăm dimensiunea coloanelor
                dataGridView1.Columns[0].HeaderText = "Autor";
                dataGridView1.Columns[1].HeaderText = "Vânzări totale (mil. exemplare)";

                // Extindem panoul pentru a găzdui graficul mărit
                panelTask4.Size = new Size(800, 700);

                // Curățăm și adăugăm controalele în panou
                panelTask4.Controls.Clear();
                panelTask4.Controls.Add(comboBoxTop); // Adaugăm ComboBox-ul la panou
                panelTask4.Controls.Add(dataGridView1);
            }
        }



        private void ButtonTask5_Click(object sender, EventArgs e)
        {
            // Ascunde celelalte panouri
            HideAllPanels();
            panelTask5.Visible = true;

            // Adăugăm titluri și descrierea graficului
            Label titleLabel = new Label
            {
                Text = "Diversitatea lingvistică a cărților",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 10),
                AutoSize = true
            };

            Label dataLabel = new Label
            {
                Text = "Graficul de mai jos ilustrează diversitatea limbilor în care au fost publicate cărțile.",
                Font = new Font("Arial", 10),
                Location = new Point(20, 40),
                AutoSize = true
            };

            // Creăm un control Chart pentru grafic
            Chart languageChart = new Chart
            {
                Size = new Size(800, 500),
                Location = new Point(20, 70)
            };
            languageChart.ChartAreas.Add(new ChartArea("MainArea"));

            // Creăm seria de tip Pie (diagramă tip cerc)
            Series series = new Series
            {
                Name = "Număr Cărți per Limbă",
                ChartType = SeriesChartType.Pie,
                IsValueShownAsLabel = true,
                LabelForeColor = Color.Black,
                BorderWidth = 1,
                BorderColor = Color.DarkGray
            };

            // Grupăm cărțile pe limbă și calculăm câte cărți sunt publicate în fiecare limbă
            var languageDistribution = dataTable.AsEnumerable()
                .GroupBy(row => row.Field<string>("Original Language"))
                .Select(group => new
                {
                    Language = group.Key,
                    Count = group.Count()
                })
                .OrderByDescending(x => x.Count) // Ordonăm după numărul de cărți, descrescător
                .ToList();

            // Adăugăm datele în serie
            foreach (var item in languageDistribution)
            {
                series.Points.AddXY(item.Language, item.Count);
            }

            // Adăugăm seria pe grafic
            languageChart.Series.Add(series);

            // Adăugăm legenda
            languageChart.Legends.Clear();
            languageChart.Legends.Add(new Legend("Legend")
            {
                Docking = Docking.Top,
                Alignment = StringAlignment.Center
            });

            // Setăm configurația axelor pentru claritate
            languageChart.ChartAreas[0].Area3DStyle.Enable3D = true;
            languageChart.ChartAreas[0].Area3DStyle.Perspective = 10;
            languageChart.ChartAreas[0].AxisX.Enabled = AxisEnabled.False; // Ascundem axa X
            languageChart.ChartAreas[0].AxisY.Enabled = AxisEnabled.False; // Ascundem axa Y

            // Ajustează dimensiunile panoului pentru a se potrivi graficului
            panelTask5.Size = new Size(900, 600); // Mărește dimensiunile panoului

            // Adăugăm elementele pe panou
            panelTask5.Controls.Clear();
            panelTask5.Controls.Add(titleLabel);
            panelTask5.Controls.Add(dataLabel);
            panelTask5.Controls.Add(languageChart);
        }



        private void PopulateComboBox()
        {
            comboBoxTop.Items.Clear();
            comboBoxTop.Items.Add("Top 5");
            comboBoxTop.Items.Add("Top 10");
            comboBoxTop.SelectedIndex = 0; // Setează "Top 5" ca opțiunea selectată implicit
        }

        private void HideAllPanels()
        {
            panelTask1.Visible = false;
            panelTask2.Visible = false;
            panelTask3.Visible = false;
            panelTask4.Visible = false;
            panelTask5.Visible = false;
        }
    }
}
