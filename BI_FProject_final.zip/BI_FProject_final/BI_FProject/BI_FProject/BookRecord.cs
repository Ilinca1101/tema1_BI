﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BI_FProject
{
    public class BookRecord
    {
        public string Book { get; set; }
        public string Author { get; set; } // 
        public string OriginalLanguage { get; set; } // Modifică la "Original language"
        public int FirstPublished { get; set; } // Modifică la "First published"
        public double ApproximateSalesInMillions { get; set; } // Modifică la "Approximate sales in millions"
        public string Genre { get; set; }
    }
}
